package in.co.air.line.ticket.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import beanObjs.BaseBean;
import beanObjs.CustomerBean;
import beanObjs.UserBean;
import in.co.air.line.ticket.exception.ApplicationException;
import in.co.air.line.ticket.exception.DuplicateRecordException;
import in.co.air.line.ticket.model.AirLineModel;
import in.co.air.line.ticket.model.CustomerModel;
import in.co.air.line.ticket.util.DataUtility;
import in.co.air.line.ticket.util.DataValidator;
import in.co.air.line.ticket.util.PropertyReader;
import in.co.air.line.ticket.util.ServletUtility;

/**
 * Servlet implementation class CustomerCtl
 */
@WebServlet(name="CustomerCtl",urlPatterns={"/ctl/CustomerCtl"})
public class CustomerCtl extends BaseCtl {
	private static final long serialVersionUID = 1L;
       
	private static Logger log=Logger.getLogger(CustomerCtl.class);
	/**
	 * Validate input Data Entered By User
	 * 
	 * @param request
	 * @return
	 */

	@Override
    protected boolean validate(HttpServletRequest request) {
		log.debug("CustomerCtl validate method start");
        boolean pass = true;

       
        if (DataValidator.isNull(request.getParameter("address"))) {
            request.setAttribute("address",
                    PropertyReader.getValue("error.require", "Address"));
            pass = false;
        }
        
        
        if (DataValidator.isNull(request.getParameter("city"))) {
            request.setAttribute("city",
                    PropertyReader.getValue("error.require", "city"));
            pass = false;
        }
        if (DataValidator.isNull(request.getParameter("zipCode"))) {
            request.setAttribute("zipCode",
                    PropertyReader.getValue("error.require", "ZiP Code"));
            pass = false;
        }
        if (DataValidator.isNull(request.getParameter("telephone"))) {
            request.setAttribute("telephone",
                    PropertyReader.getValue("error.require", "Telephone"));
            pass = false;
        }
        if (DataValidator.isNull(request.getParameter("state"))) {
            request.setAttribute("state",
                    PropertyReader.getValue("error.require", "State"));
            pass = false;
        }
        if (DataValidator.isNull(request.getParameter("email"))) {
            request.setAttribute("email",
                    PropertyReader.getValue("error.require", "Email"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("firstName"))) {
    		
			request.setAttribute("firstName", PropertyReader.getValue("error.require", "First Name"));
			pass = false;
		}
		
		if (DataValidator.isNull(request.getParameter("lastName"))) {
			request.setAttribute("lastName", PropertyReader.getValue("error.require", "Last Name"));
			pass = false;
		}
      
        log.debug("CustomerCtl validate method end");
        return pass;
    }
	
	

	@Override
	protected BaseBean populateBean(HttpServletRequest request) {
		log.debug("CustomerCtl populateBean method start");
		CustomerBean bean=new CustomerBean();
		bean.setId(DataUtility.getLong(request.getParameter("id")));
		bean.setAddress(DataUtility.getString(request.getParameter("address")));
		bean.setCity(DataUtility.getString(request.getParameter("city")));
		bean.setZipCode(DataUtility.getString(request.getParameter("zipCode")));
		bean.setTelephone(DataUtility.getString(request.getParameter("telephone")));
		bean.setState(DataUtility.getString(request.getParameter("state")));
		bean.setEmail(DataUtility.getString(request.getParameter("email")));
		bean.setFirstName(DataUtility.getString(request.getParameter("firstName")));
		bean.setLastName(DataUtility.getString(request.getParameter("lastName")));
		bean.setUserId(DataUtility.getLong(request.getParameter("userId")));
		log.debug("CustomerCtl populateBean method end");
		return bean;
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug("CustomerCtl doGet method start"); 
		String op = DataUtility.getString(request.getParameter("operation"));
			
		   CustomerModel model = new CustomerModel();
			long id = DataUtility.getLong(request.getParameter("id"));
			
			Long rid=DataUtility.getLong(request.getParameter("rId"));
			if(rid>0) {
				request.getSession().setAttribute("rId",rid);
			}
			try {
			UserBean uBean=(UserBean)request.getSession().getAttribute("user");
			CustomerBean cBean=model.findByUserId(uBean.getId());
			if(cBean!=null) {
				ServletUtility.setBean(cBean, request);
			}
			ServletUtility.setOpration("Add", request);
			if (id > 0 || op != null) {
				System.out.println("in id > 0  condition");
				CustomerBean bean;
				
					bean = model.findByPK(id);
					ServletUtility.setOpration("Edit", request);
					ServletUtility.setBean(bean, request);
				}
				} catch (ApplicationException e) {
					ServletUtility.handleException(e, request, response);
					return;
				}
			
			ServletUtility.forward(getView(), request, response);
			log.debug("CustomerCtl doGet method end");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug("CustomerCtl doPost method start");
		String op=DataUtility.getString(request.getParameter("operation"));
		CustomerModel model=new CustomerModel();
		
		long id=0;
				UserBean uBean=(UserBean)request.getSession().getAttribute("user");
				if(uBean.getRoleId()==1) {
				id=DataUtility.getLong(request.getParameter("id"));
				}
		if(OP_SAVE.equalsIgnoreCase(op)){
			
			CustomerBean bean=(CustomerBean)populateBean(request);
				try {
					if(id>0){
						
					model.update(bean);
					ServletUtility.setOpration("Edit", request);
					ServletUtility.setSuccessMessage("Data is successfully Updated", request);
	                ServletUtility.setBean(bean, request);

					}else {
						bean.setUserId(uBean.getId());
						request.getSession().setAttribute("customer",bean);
						ServletUtility.redirect(ATBView.RESERVATION_CTL, request, response);
						return;
					}
	              
				} catch (ApplicationException e) {
					e.printStackTrace();
					ServletUtility.forward(ATBView.ERROR_VIEW, request, response);
					return;
				
			} catch (DuplicateRecordException e) {
				ServletUtility.setBean(bean, request);
				ServletUtility.setErrorMessage(e.getMessage(),
						request);
			}
			
		}else if (OP_CANCEL.equalsIgnoreCase(op)) {
			ServletUtility.redirect(ATBView.INDEX_CTL, request, response);
			return;
		}else if (OP_RESET.equalsIgnoreCase(op)) {
		ServletUtility.redirect(ATBView.CUSTOMER_CTL, request, response);
		return;
}
				
		
		ServletUtility.forward(getView(), request, response);
		 log.debug("CustomerCtl doPost method end");
	}

	@Override
	protected String getView() {
		// TODO Auto-generated method stub
		return ATBView.CUSTOMER_VIEW;
	}

}
