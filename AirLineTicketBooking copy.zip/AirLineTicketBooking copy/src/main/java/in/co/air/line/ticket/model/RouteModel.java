package in.co.air.line.ticket.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import beanObjs.RouteBean;
import in.co.air.line.ticket.exception.ApplicationException;
import in.co.air.line.ticket.exception.DatabaseException;
import in.co.air.line.ticket.exception.DuplicateRecordException;
import in.co.air.line.ticket.util.JDBCDataSource;

public class RouteModel {

private static Logger log = Logger.getLogger(RouteModel.class);
	

	public Integer nextPK() throws DatabaseException {
		log.debug("Model nextPK Started");
		Connection conn = null;
		int pk = 0;

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(ID) FROM Route");
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				pk = rs.getInt(1);
			}
			rs.close();

		} catch (Exception e) {
			log.error("Database Exception..", e);
			throw new DatabaseException("Exception : Exception in getting PK");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("Model nextPK End");
		return pk + 1;
	}

	/**
	 * Add a Route
	 * 
	 * @param bean
	 * @throws DatabaseException
	 * 
	 */
	public long add(RouteBean bean) throws ApplicationException, DuplicateRecordException {
		
		Connection conn = null;
		int pk = 0;

		/*RouteBean existbean = findByRouteNo(bean.getRouteNo());

		if (existbean != null) {
			throw new DuplicateRecordException("Route already exists");
		}*/

		try {
			conn = JDBCDataSource.getConnection();
			pk = nextPK();
			// Get auto-generated next primary key
			System.out.println(pk + " in ModelJDBC");
			conn.setAutoCommit(false); // Begin transaction
			PreparedStatement pstmt = conn.prepareStatement("INSERT INTO Route VALUES(?,?,?,?,?,?,?,?,?)");
			pstmt.setInt(1, pk);
			pstmt.setLong(2,bean.getFlightId());
			pstmt.setLong(3,bean.getAirLineId());
			pstmt.setLong(4,bean.getDeptAirportId());
			pstmt.setLong(5,bean.getArriveAirPortId());
			pstmt.setString(6,bean.getDeptTime());
			pstmt.setString(7,bean.getArriveTime());
			pstmt.setDate(8,new java.sql.Date(bean.getDeptDate().getTime()));
			pstmt.setDouble(9,bean.getTicketPrice());
			pstmt.executeUpdate();
			conn.commit(); // End transaction
			pstmt.close();
		} catch (Exception e) {
		
			try {
				conn.rollback();
			} catch (Exception ex) {
				ex.printStackTrace();
				throw new ApplicationException("Exception : add rollback exception " + ex.getMessage());
			}
			throw new ApplicationException("Exception : Exception in add Route");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		
		return pk;
	}

	/**
	 * Delete a Route
	 * 
	 * @param bean
	 * @throws DatabaseException
	 */
	public void delete(RouteBean bean) throws ApplicationException {
		
		Connection conn = null;
		try {
			conn = JDBCDataSource.getConnection();
			conn.setAutoCommit(false); // Begin transaction
			PreparedStatement pstmt = conn.prepareStatement("DELETE FROM Route WHERE ID=?");
			pstmt.setLong(1, bean.getId());
			pstmt.executeUpdate();
			conn.commit(); // End transaction
			pstmt.close();

		} catch (Exception e) {
		
			try {
				conn.rollback();
			} catch (Exception ex) {
				throw new ApplicationException("Exception : Delete rollback exception " + ex.getMessage());
			}
			throw new ApplicationException("Exception : Exception in delete Route");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		
	}

	/**
	 * Find Route by Login
	 * 
	 * @param login
	 *            : get parameter
	 * @return bean
	 * @throws DatabaseException
	 */

	public RouteBean findByRouteNo(String RouteNo) throws ApplicationException {
		log.debug("Model findByLogin Started");
		StringBuffer sql = new StringBuffer("SELECT * FROM Route WHERE Route_No=?");
		RouteBean bean = null;
		Connection conn = null;
		System.out.println("sql" + sql);

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, RouteNo);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				bean = new RouteBean();
				bean.setId(rs.getLong(1));
				bean.setFlightId(rs.getLong(2));
				bean.setAirLineId(rs.getLong(3));
				bean.setDeptAirportId(rs.getLong(4));
				bean.setArriveAirPortId(rs.getLong(5));
				bean.setDeptTime(rs.getString(6));
				bean.setArriveTime(rs.getString(7));
				bean.setDeptDate(rs.getDate(8));
				bean.setTicketPrice(rs.getDouble(9));
			}
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Database Exception..", e);
			throw new ApplicationException("Exception : Exception in getting Route by login");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("Model findByLogin End");
		return bean;
	}

	/**
	 * Find Route by PK
	 * 
	 * @param pk
	 *            : get parameter
	 * @return bean
	 * @throws DatabaseException
	 */

	public RouteBean findByPK(long pk) throws ApplicationException {
		log.debug("Model findByPK Started");
		StringBuffer sql = new StringBuffer("SELECT * FROM Route WHERE ID=?");
		RouteBean bean = null;
		Connection conn = null;

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setLong(1, pk);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				bean = new RouteBean();
				bean.setId(rs.getLong(1));
				bean.setFlightId(rs.getLong(2));
				bean.setAirLineId(rs.getLong(3));
				bean.setDeptAirportId(rs.getLong(4));
				bean.setArriveAirPortId(rs.getLong(5));
				bean.setDeptTime(rs.getString(6));
				bean.setArriveTime(rs.getString(7));
				bean.setDeptDate(rs.getDate(8));
				bean.setTicketPrice(rs.getDouble(9));
			}
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Database Exception..", e);
			throw new ApplicationException("Exception : Exception in getting Route by pk");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("Model findByPK End");
		return bean;
	}

	/**
	 * Update a Route
	 * 
	 * @param bean
	 * @throws DatabaseException
	 */

	public void update(RouteBean bean) throws ApplicationException, DuplicateRecordException {
		log.debug("Model update Started");
		Connection conn = null;

		/*RouteBean beanExist = findByRouteNo(bean.getRouteNo());
		// Check if updated LoginId already exist
		if (beanExist != null && !(beanExist.getId() == bean.getId())) {
			throw new DuplicateRecordException("Route is already exist");
		}*/

		try {
			conn = JDBCDataSource.getConnection();
			conn.setAutoCommit(false); // Begin transaction
			PreparedStatement pstmt = conn.prepareStatement(
					"UPDATE Route SET flight_id=?,airLine_Id=?,Dept_airport_Id=?,Arrive_Airport_Id=?,dept_time=?,arrival_time=?,dept_Date=?,ticket_price=?"
					+ " WHERE ID=?");
			pstmt.setLong(1,bean.getFlightId());
			pstmt.setLong(2,bean.getAirLineId());
			pstmt.setLong(3,bean.getDeptAirportId());
			pstmt.setLong(4,bean.getArriveAirPortId());
			pstmt.setString(5,bean.getDeptTime());
			pstmt.setString(6,bean.getArriveTime());
			pstmt.setDate(7,new java.sql.Date(bean.getDeptDate().getTime()));
			pstmt.setDouble(8,bean.getTicketPrice());
			pstmt.setLong(9,bean.getId());
			pstmt.executeUpdate();
			conn.commit(); // End transaction
			pstmt.close();
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Database Exception..", e);
			try {
				conn.rollback();
			} catch (Exception ex) {
				throw new ApplicationException("Exception : Delete rollback exception " + ex.getMessage());
			}
			throw new ApplicationException("Exception in updating Route ");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("Model update End");
	}

	/**
	 * Search Route
	 * 
	 * @param bean
	 *            : Search Parameters
	 * @throws DatabaseException
	 */

	public List search(RouteBean bean) throws ApplicationException {
		return search(bean, 0, 0);
	}

	

	public List search(RouteBean bean, int pageNo, int pageSize) throws ApplicationException {
		log.debug("Model search Started");
		StringBuffer sql = new StringBuffer("SELECT * FROM Route WHERE 1=1");

		if (bean != null) {
			if (bean.getId() > 0) {
				sql.append(" AND id = " + bean.getId());
			}
			/*if (bean.getRouteNo() != null && bean.getRouteNo().length() > 0) {
				sql.append(" AND Route_No like '" + bean.getRouteNo() + "%'");
			}*/
			
			
		

		}

		// if page size is greater than zero then apply pagination
		if (pageSize > 0) {
			// Calculate start record index
			pageNo = (pageNo - 1) * pageSize;

			sql.append(" Limit " + pageNo + ", " + pageSize);
			// sql.append(" limit " + pageNo + "," + pageSize);
		}

		System.out.println("Route model search  :"+sql);
		ArrayList list = new ArrayList();
		Connection conn = null;
		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				bean = new RouteBean();
				bean.setId(rs.getLong(1));
				bean.setFlightId(rs.getLong(2));
				bean.setAirLineId(rs.getLong(3));
				bean.setDeptAirportId(rs.getLong(4));
				bean.setArriveAirPortId(rs.getLong(5));
				bean.setDeptTime(rs.getString(6));
				bean.setArriveTime(rs.getString(7));
				bean.setDeptDate(rs.getDate(8));
				bean.setTicketPrice(rs.getDouble(9));
				list.add(bean);
			}
			rs.close();
		} catch (Exception e) {
			log.error("Database Exception..", e);
			throw new ApplicationException("Exception : Exception in search Route");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}

		log.debug("Model search End");
		return list;
	}

	/**
	 * Get List of Route
	 * 
	 * @return list : List of Route
	 * @throws DatabaseException
	 */

	public List list() throws ApplicationException {
		return list(0, 0);
	}

	/**
	 * Get List of Route with pagination
	 * 
	 * @return list : List of Routes
	 * @param pageNo
	 *            : Current Page No.
	 * @param pageSize
	 *            : Size of Page
	 * @throws DatabaseException
	 */

	public List list(int pageNo, int pageSize) throws ApplicationException {
		log.debug("Model list Started");
		ArrayList list = new ArrayList();
		StringBuffer sql = new StringBuffer("select * from Route");
		// if page size is greater than zero then apply pagination
		if (pageSize > 0) {
			// Calculate start record index
			pageNo = (pageNo - 1) * pageSize;
			sql.append(" limit " + pageNo + "," + pageSize);
		}

		
		System.out.println("sql in list Route :"+sql);
		Connection conn = null;

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				RouteBean bean = new RouteBean();
				bean.setId(rs.getLong(1));
				bean.setFlightId(rs.getLong(2));
				bean.setAirLineId(rs.getLong(3));
				bean.setDeptAirportId(rs.getLong(4));
				bean.setArriveAirPortId(rs.getLong(5));
				bean.setDeptTime(rs.getString(6));
				bean.setArriveTime(rs.getString(7));
				bean.setDeptDate(rs.getDate(8));
				bean.setTicketPrice(rs.getDouble(9));
				list.add(bean);
			}
			rs.close();
		} catch (Exception e) {
			log.error("Database Exception..", e);
			throw new ApplicationException("Exception : Exception in getting list of Route");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}

		log.debug("Model list End");
		return list;

	}
}
