package in.co.air.line.ticket.controller;

public interface ATBView {
	
	public String APP_CONTEXT = "/AirLineTicketBooking";

	public String LAYOUT_VIEW = "/BaseLayout.jsp";
	public String PAGE_FOLDER = "/jsp";

	public String JAVA_DOC_VIEW = APP_CONTEXT + "/doc/index.html";

	public String ERROR_VIEW = PAGE_FOLDER + "/Error.jsp";

	
	
	public String USER_VIEW = PAGE_FOLDER + "/UserView.jsp";	
	public String USER_LIST_VIEW = PAGE_FOLDER + "/UserListView.jsp";
	public String USER_REGISTRATION_VIEW = PAGE_FOLDER + "/UserRegistrationView.jsp";
	
	
	
	public String PAYMENT_VIEW = PAGE_FOLDER + "/PaymentView.jsp";
	
	public String FLIGHT_VIEW = PAGE_FOLDER + "/FlightView.jsp";	
	public String FLIGHT_LIST_VIEW = PAGE_FOLDER + "/FlightListView.jsp";
	
	public String AIRLINE_VIEW = PAGE_FOLDER + "/AirLineView.jsp";	
	public String AIRLINE_LIST_VIEW = PAGE_FOLDER + "/AirLineListView.jsp";
	
	public String AIRPORT_VIEW = PAGE_FOLDER + "/AirportView.jsp";	
	public String AIRPORT_LIST_VIEW = PAGE_FOLDER + "/AirportListView.jsp";
	
	public String ROUTE_VIEW = PAGE_FOLDER + "/RouteView.jsp";	
	public String ROUTE_LIST_VIEW = PAGE_FOLDER + "/RouteListView.jsp";
	
	public String RESERVATION_VIEW = PAGE_FOLDER + "/ReservationView.jsp";	
	public String RESERVATION_LIST_VIEW = PAGE_FOLDER + "/ReservationListView.jsp";
	
	
	public String SELES_REPORT_LIST_VIEW = PAGE_FOLDER + "/SelesReportListView.jsp";
	
	public String CUSTOMER_VIEW = PAGE_FOLDER + "/CustomerView.jsp";	
	public String CUSTOMER_LIST_VIEW = PAGE_FOLDER + "/CustomerListView.jsp";
	
	public String INDEX_VIEW ="/index.jsp";
	
	public String LOGIN_VIEW = PAGE_FOLDER + "/LoginView.jsp";
	public String WELCOME_VIEW = PAGE_FOLDER + "/Welcome.jsp";
	public String CHANGE_PASSWORD_VIEW = PAGE_FOLDER + "/ChangePasswordView.jsp";
	public String MY_PROFILE_VIEW = PAGE_FOLDER + "/MyProfileView.jsp";
	public String FORGET_PASSWORD_VIEW = PAGE_FOLDER + "/ForgetPasswordView.jsp";

	
	

	public String ERROR_CTL = "/ctl/ErrorCtl";

	
	
	public String USER_CTL = APP_CONTEXT + "/ctl/UserCtl";
	public String USER_LIST_CTL = APP_CONTEXT + "/ctl/UserListCtl";
	
	public String FLIGHT_CTL = APP_CONTEXT + "/ctl/FlightCtl";
	public String FLIGHT_LIST_CTL = APP_CONTEXT + "/ctl/FlightListCtl";
	
	public String INDEX_CTL = APP_CONTEXT + "/IndexCtl";
	
	public String AIRLINE_CTL = APP_CONTEXT + "/ctl/AirLineCtl";
	public String AIRLINE_LIST_CTL = APP_CONTEXT + "/ctl/AirLineListCtl";
	
	public String AIRPORT_CTL = APP_CONTEXT + "/ctl/AirportCtl";
	public String AIRPORT_LIST_CTL = APP_CONTEXT + "/ctl/AirportListCtl";
	
	public String ROUTE_CTL = APP_CONTEXT + "/ctl/RouteCtl";
	public String ROUTE_LIST_CTL = APP_CONTEXT + "/ctl/RouteListCtl";
	
	public String RESERVATION_CTL = APP_CONTEXT + "/ctl/ReservationCtl";
	public String RESERVATION_LIST_CTL = APP_CONTEXT + "/ctl/ReservationListCtl";
	
	
	public String SELES_REPORT_LIST_CTL = APP_CONTEXT + "/ctl/SelesReportListCtl";
	
	public String CUSTOMER_CTL = APP_CONTEXT + "/ctl/CustomerCtl";
	public String CUSTOMER_LIST_CTL = APP_CONTEXT + "/ctl/CustomerListCtl";
	
	public String USER_REGISTRATION_CTL = APP_CONTEXT + "/UserRegistrationCtl";
	public String LOGIN_CTL = APP_CONTEXT + "/LoginCtl";
	public String WELCOME_CTL = APP_CONTEXT + "/WelcomeCtl";
	public String LOGOUT_CTL = APP_CONTEXT + "/LoginCtl";
	public String CHANGE_PASSWORD_CTL = APP_CONTEXT + "/ctl/ChangePasswordCtl";
	public String MY_PROFILE_CTL = APP_CONTEXT + "/ctl/MyProfileCtl";
	public String FORGET_PASSWORD_CTL = APP_CONTEXT + "/ForgetPasswordCtl";



}
