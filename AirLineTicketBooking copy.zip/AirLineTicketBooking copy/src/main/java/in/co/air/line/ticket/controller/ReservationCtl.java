package in.co.air.line.ticket.controller;

import java.io.IOException;
import java.time.LocalTime;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import beanObjs.BaseBean;
import beanObjs.CustomerBean;
import beanObjs.ReservationBean;
import beanObjs.RouteBean;
import beanObjs.UserBean;
import in.co.air.line.ticket.exception.ApplicationException;
import in.co.air.line.ticket.exception.DuplicateRecordException;
import in.co.air.line.ticket.model.AirLineModel;
import in.co.air.line.ticket.model.CustomerModel;
import in.co.air.line.ticket.model.ReservationModel;
import in.co.air.line.ticket.model.RouteModel;
import in.co.air.line.ticket.util.DataUtility;
import in.co.air.line.ticket.util.DataValidator;
import in.co.air.line.ticket.util.PropertyReader;
import in.co.air.line.ticket.util.ServletUtility;

/**
 * Servlet implementation class ReservationCtl
 */
@WebServlet(name="ReservationCtl",urlPatterns={"/ctl/ReservationCtl"})
public class ReservationCtl extends BaseCtl {
	private static final long serialVersionUID = 1L;
       
	private static Logger log=Logger.getLogger(ReservationCtl.class);
	/**
	 * Validate input Data Entered By User
	 * 
	 * @param request
	 * @return
	 */

	@Override
    protected boolean validate(HttpServletRequest request) {
		log.debug("ReservationCtl validate method start");
        boolean pass = true;

       
        if (DataValidator.isNull(request.getParameter("accNo"))) {
            request.setAttribute("accNo",
                    PropertyReader.getValue("error.require", "Account Number"));
            pass = false;
        }
        
        
        if (DataValidator.isNull(request.getParameter("cCard"))) {
            request.setAttribute("cCard",
                    PropertyReader.getValue("error.require", "Credit Card"));
            pass = false;
        }
        if (DataValidator.isNull(request.getParameter("date"))) {
            request.setAttribute("date",
                    PropertyReader.getValue("error.require", "Account Date"));
            pass = false;
        }
        if (DataValidator.isNull(request.getParameter("pref"))) {
            request.setAttribute("pref",
                    PropertyReader.getValue("error.require", "Preferences"));
            pass = false;
        }
        log.debug("ReservationCtl validate method end");
        return pass;
    }
	
	

	@Override
	protected BaseBean populateBean(HttpServletRequest request) {
		log.debug("ReservationCtl populateBean method start");
		CustomerBean bean=new CustomerBean();
		bean.setId(DataUtility.getLong(request.getParameter("id")));
		bean.setAccountNum(DataUtility.getString(request.getParameter("accNo")));
		bean.setCreaditCard(DataUtility.getString(request.getParameter("cCard")));
		bean.setAccountDate(DataUtility.getString(request.getParameter("date")));
		bean.setPreferences(DataUtility.getString(request.getParameter("pref")));
		
		log.debug("ReservationCtl populateBean method end");
		return bean;
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug("ReservationCtl doGet method start"); 
		String op = DataUtility.getString(request.getParameter("operation"));

		Long rid=(Long)request.getSession().getAttribute("rId");
		
		HttpSession session=request.getSession();
		
		if(rid>0) {
			RouteBean fBean = null;
			try {
				fBean = new RouteModel().findByPK(rid);
			} catch (ApplicationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		long duration  = fBean.getDeptDate().getTime() - new java.util.Date().getTime();
		long days = TimeUnit.MILLISECONDS.toDays(duration);
		//if(cuttentDate)
		if(days==3) {
			session.setAttribute("disc",String.valueOf(fBean.getTicketPrice())+" After Discount Of $"+String.valueOf(fBean.getTicketPrice()-5.0));
		}else if(days>3 && days<7){
			session.setAttribute("disc",String.valueOf(fBean.getTicketPrice())+" After Discount Of $"+String.valueOf(fBean.getTicketPrice()-25.0));
		}else if(days>=7 && days<14){
			session.setAttribute("disc",String.valueOf(fBean.getTicketPrice())+" After Discount Of $"+String.valueOf(fBean.getTicketPrice()-50.0));
		}else if(days>=14 && days<=21){
			session.setAttribute("disc",String.valueOf(fBean.getTicketPrice())+" After Discount Of $"+String.valueOf(fBean.getTicketPrice()-100.0));
		}else {
			session.setAttribute("disc",String.valueOf(fBean.getTicketPrice())+" No Discount Available");
		}
		
		}
		
		   ReservationModel model = new ReservationModel();
			long id = DataUtility.getLong(request.getParameter("id"));
			ServletUtility.setOpration("Add", request);
			if (id > 0 || op != null) {
				System.out.println("in id > 0  condition");
				ReservationBean bean;
				try {
					bean = model.findByPK(id);
					ServletUtility.setOpration("Edit", request);
					ServletUtility.setBean(bean, request);
				} catch (ApplicationException e) {
					ServletUtility.handleException(e, request, response);
					return;
				}
			}

			ServletUtility.forward(getView(), request, response);
			log.debug("ReservationCtl doGet method end");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug("ReservationCtl doPost method start");
		String op=DataUtility.getString(request.getParameter("operation"));
		ReservationModel model=new ReservationModel();
		CustomerModel cModel=new CustomerModel();
		RouteModel eModel=new RouteModel();
		long id=DataUtility.getLong(request.getParameter("id"));
		if(OP_SAVE.equalsIgnoreCase(op)){
			
			CustomerBean bean=(CustomerBean)populateBean(request);
				try {
					
					
					
						Long rid=(Long)request.getSession().getAttribute("rId");
						RouteBean rBean=eModel.findByPK(rid);
						long pk=0;
						UserBean uBean=(UserBean)request.getSession().getAttribute("user");
						CustomerBean ccBean=cModel.findByUserId(uBean.getId());
						if(ccBean!=null) {
							CustomerBean cBean=(CustomerBean)request.getSession().getAttribute("customer");
							cBean.setAccountNum(bean.getAccountNum());
							cBean.setAccountDate(bean.getAccountDate());
							cBean.setCreaditCard(bean.getCreaditCard());
							cBean.setPreferences(bean.getPreferences());
							cModel.update(cBean);
							pk=ccBean.getId();
						}else {
						
						CustomerBean cBean=(CustomerBean)request.getSession().getAttribute("customer");
						cBean.setAccountNum(bean.getAccountNum());
						cBean.setAccountDate(bean.getAccountDate());
						cBean.setCreaditCard(bean.getCreaditCard());
						cBean.setPreferences(bean.getPreferences());
						pk=cModel.add(cBean);
						}
						ReservationBean rsBean=new ReservationBean();
						
						HttpSession session=request.getSession();
						
					
						long duration  = rBean.getDeptDate().getTime() - new java.util.Date().getTime();
						long days = TimeUnit.MILLISECONDS.toDays(duration);
						//if(cuttentDate)
						if(days==3) {
							rsBean.setTotalFare(rBean.getTicketPrice()-5.0);
							session.setAttribute("disc",String.valueOf(rBean.getTicketPrice())+" After Discount Of $"+String.valueOf(rBean.getTicketPrice()-5.0));
						}else if(days>3 && days<7){
							rsBean.setTotalFare(rBean.getTicketPrice()-25.0);
							session.setAttribute("disc",String.valueOf(rBean.getTicketPrice())+" After Discount Of $"+String.valueOf(rBean.getTicketPrice()-25.0));
						}else if(days>=7 && days<14){
							rsBean.setTotalFare(rBean.getTicketPrice()-50.0);
							session.setAttribute("disc",String.valueOf(rBean.getTicketPrice())+" After Discount Of $"+String.valueOf(rBean.getTicketPrice()-50.0));
						}else if(days>=14 && days<=21){
							rsBean.setTotalFare(rBean.getTicketPrice()-100.0);
							session.setAttribute("disc",String.valueOf(rBean.getTicketPrice())+" After Discount Of $"+String.valueOf(rBean.getTicketPrice()-100.0));
						}else {
							rsBean.setTotalFare(rBean.getTicketPrice());
							session.setAttribute("disc",String.valueOf(rBean.getTicketPrice())+" No Discount Available");
						}
					
						
						rsBean.setCustomerId(pk);
						rsBean.setAirLineId(rBean.getAirLineId());
						rsBean.setArriveAirportId(rBean.getArriveAirPortId());
						rsBean.setReservationDate(DataUtility.getDateString(new Date()));
						rsBean.setMonth(String.valueOf(new Date().getMonth()+1));
						rsBean.setDeptAirportId(rBean.getDeptAirportId());
						rsBean.setBookingFee(0.0);
						rsBean.setFlightId(rBean.getFlightId());
						model.add(rsBean);
						
						request.setAttribute("msg","Ticket Booked SuccessFully!!");
				} catch (ApplicationException e) {
					e.printStackTrace();
					ServletUtility.forward(ATBView.ERROR_VIEW, request, response);
					return;
				
			} catch (DuplicateRecordException e) {
				ServletUtility.setBean(bean, request);
				ServletUtility.setErrorMessage(e.getMessage(),
						request);
			}
			
		}else if (OP_CANCEL.equalsIgnoreCase(op)) {
			ServletUtility.redirect(ATBView.INDEX_CTL, request, response);
			return;
		}else if (OP_RESET.equalsIgnoreCase(op)) {
		ServletUtility.redirect(ATBView.RESERVATION_CTL, request, response);
		return;
}
				
		
		ServletUtility.forward(getView(), request, response);
		 log.debug("ReservationCtl doPost method end");
	}

	@Override
	protected String getView() {
		// TODO Auto-generated method stub
		return ATBView.RESERVATION_VIEW;
	}

}
