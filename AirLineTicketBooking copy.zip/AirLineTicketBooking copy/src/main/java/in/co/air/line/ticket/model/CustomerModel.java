package in.co.air.line.ticket.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import beanObjs.CustomerBean;
import in.co.air.line.ticket.exception.ApplicationException;
import in.co.air.line.ticket.exception.DatabaseException;
import in.co.air.line.ticket.exception.DuplicateRecordException;
import in.co.air.line.ticket.util.JDBCDataSource;

public class CustomerModel {
	
private static Logger log = Logger.getLogger(CustomerModel.class);
	

	public Integer nextPK() throws DatabaseException {
		log.debug("Model nextPK Started");
		Connection conn = null;
		int pk = 0;

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(ID) FROM Customer");
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				pk = rs.getInt(1);
			}
			rs.close();

		} catch (Exception e) {
			log.error("Database Exception..", e);
			throw new DatabaseException("Exception : Exception in getting PK");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("Model nextPK End");
		return pk + 1;
	}

	/**
	 * Add a Customer
	 * 
	 * @param bean
	 * @throws DatabaseException
	 * 
	 */
	public long add(CustomerBean bean) throws ApplicationException, DuplicateRecordException {
		
		Connection conn = null;
		int pk = 0;

		CustomerBean existbean = findByEmail(bean.getEmail());

		if (existbean != null) {
			throw new DuplicateRecordException("Customer already exists");
		}

		try {
			conn = JDBCDataSource.getConnection();
			pk = nextPK();
			// Get auto-generated next primary key
			System.out.println(pk + " in ModelJDBC");
			conn.setAutoCommit(false); // Begin transaction
			PreparedStatement pstmt = conn.prepareStatement("INSERT INTO Customer VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			pstmt.setInt(1, pk);
			pstmt.setString(2, bean.getFirstName());
			pstmt.setString(3, bean.getLastName());
			pstmt.setString(4, bean.getAddress());
			pstmt.setString(5, bean.getCity());
			pstmt.setString(6, bean.getState());
			pstmt.setString(7, bean.getZipCode());
			pstmt.setString(8, bean.getTelephone());
			pstmt.setString(9, bean.getEmail());
			pstmt.setString(10, bean.getAccountNum());
			pstmt.setString(11, bean.getAccountDate());
			pstmt.setString(12, bean.getCreaditCard());
			pstmt.setString(13, bean.getPreferences());
			pstmt.setLong(14,bean.getUserId());
			pstmt.executeUpdate();
			conn.commit(); // End transaction
			pstmt.close();
		} catch (Exception e) {
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (Exception ex) {
				ex.printStackTrace();
				throw new ApplicationException("Exception : add rollback exception " + ex.getMessage());
			}
			throw new ApplicationException("Exception : Exception in add Customer");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		
		return pk;
	}

	/**
	 * Delete a Customer
	 * 
	 * @param bean
	 * @throws DatabaseException
	 */
	public void delete(CustomerBean bean) throws ApplicationException {
		
		Connection conn = null;
		try {
			conn = JDBCDataSource.getConnection();
			conn.setAutoCommit(false); // Begin transaction
			PreparedStatement pstmt = conn.prepareStatement("DELETE FROM Customer WHERE ID=?");
			pstmt.setLong(1, bean.getId());
			pstmt.executeUpdate();
			conn.commit(); // End transaction
			pstmt.close();

		} catch (Exception e) {
		
			try {
				conn.rollback();
			} catch (Exception ex) {
				throw new ApplicationException("Exception : Delete rollback exception " + ex.getMessage());
			}
			throw new ApplicationException("Exception : Exception in delete Customer");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		
	}

	/**
	 * Find Customer by Login
	 * 
	 * @param login
	 *            : get parameter
	 * @return bean
	 * @throws DatabaseException
	 */

	public CustomerBean findByEmail(String email) throws ApplicationException {
		log.debug("Model findByLogin Started");
		StringBuffer sql = new StringBuffer("SELECT * FROM Customer WHERE EMAIL=?");
		CustomerBean bean = null;
		Connection conn = null;
		System.out.println("sql" + sql);

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, email);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				bean = new CustomerBean();
				bean.setId(rs.getLong(1));
				bean.setFirstName(rs.getString(2));
				bean.setLastName(rs.getString(3));
				bean.setAddress(rs.getString(4));
				bean.setCity(rs.getString(5));
				bean.setState(rs.getString(6));
				bean.setZipCode(rs.getString(7));
				bean.setTelephone(rs.getString(8));
				bean.setEmail(rs.getString(9));
				bean.setAccountNum(rs.getString(10));
				bean.setAccountDate(rs.getString(11));
				bean.setCreaditCard(rs.getString(12));
				bean.setPreferences(rs.getString(13));
				bean.setUserId(rs.getLong(14));
			}
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Database Exception..", e);
			throw new ApplicationException("Exception : Exception in getting Customer by login");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("Model findByLogin End");
		return bean;
	}

	/**
	 * Find Customer by PK
	 * 
	 * @param pk
	 *            : get parameter
	 * @return bean
	 * @throws DatabaseException
	 */

	public CustomerBean findByPK(long pk) throws ApplicationException {
		log.debug("Model findByPK Started");
		StringBuffer sql = new StringBuffer("SELECT * FROM Customer WHERE ID=?");
		CustomerBean bean = null;
		Connection conn = null;

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setLong(1, pk);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				bean = new CustomerBean();
				bean.setId(rs.getLong(1));
				bean.setFirstName(rs.getString(2));
				bean.setLastName(rs.getString(3));
				bean.setAddress(rs.getString(4));
				bean.setCity(rs.getString(5));
				bean.setState(rs.getString(6));
				bean.setZipCode(rs.getString(7));
				bean.setTelephone(rs.getString(8));
				bean.setEmail(rs.getString(9));
				bean.setAccountNum(rs.getString(10));
				bean.setAccountDate(rs.getString(11));
				bean.setCreaditCard(rs.getString(12));
				bean.setPreferences(rs.getString(13));
				bean.setUserId(rs.getLong(14));
			}
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Database Exception..", e);
			throw new ApplicationException("Exception : Exception in getting Customer by pk");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("Model findByPK End");
		return bean;
	}
	
	public CustomerBean findByUserId(long Id) throws ApplicationException {
		log.debug("Model findByPK Started");
		StringBuffer sql = new StringBuffer("SELECT * FROM Customer WHERE user_Id=?");
		CustomerBean bean = null;
		Connection conn = null;

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setLong(1, Id);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				bean = new CustomerBean();
				bean.setId(rs.getLong(1));
				bean.setFirstName(rs.getString(2));
				bean.setLastName(rs.getString(3));
				bean.setAddress(rs.getString(4));
				bean.setCity(rs.getString(5));
				bean.setState(rs.getString(6));
				bean.setZipCode(rs.getString(7));
				bean.setTelephone(rs.getString(8));
				bean.setEmail(rs.getString(9));
				bean.setAccountNum(rs.getString(10));
				bean.setAccountDate(rs.getString(11));
				bean.setCreaditCard(rs.getString(12));
				bean.setPreferences(rs.getString(13));
				bean.setUserId(rs.getLong(14));
			}
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Database Exception..", e);
			throw new ApplicationException("Exception : Exception in getting Customer by pk");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("Model findByPK End");
		return bean;
	}
	

	/**
	 * Update a Customer
	 * 
	 * @param bean
	 * @throws DatabaseException
	 */

	public void update(CustomerBean bean) throws ApplicationException, DuplicateRecordException {
		log.debug("Model update Started");
		Connection conn = null;

		CustomerBean beanExist = findByEmail(bean.getEmail());
		// Check if updated LoginId already exist
		if (beanExist != null && !(beanExist.getId() == bean.getId())) {
			throw new DuplicateRecordException("Customer is already exist");
		}

		try {
			conn = JDBCDataSource.getConnection();
			conn.setAutoCommit(false); // Begin transaction
			PreparedStatement pstmt = conn.prepareStatement(
					"UPDATE Customer SET FirstName=?,LastName=?,address=?,city=?,state=?,Zip_Code=?,telephone=?,email=?,"
					+ "acctnumber=?,Account_Date=?,CreditCard=?,preferences=?,user_id=? WHERE ID=?");
			pstmt.setString(1, bean.getFirstName());
			pstmt.setString(2, bean.getLastName());
			pstmt.setString(3, bean.getAddress());
			pstmt.setString(4, bean.getCity());
			pstmt.setString(5, bean.getState());
			pstmt.setString(6, bean.getZipCode());
			pstmt.setString(7, bean.getTelephone());
			pstmt.setString(8, bean.getEmail());
			pstmt.setString(9, bean.getAccountNum());
			pstmt.setString(10, bean.getAccountDate());
			pstmt.setString(11, bean.getCreaditCard());
			pstmt.setString(12, bean.getPreferences());
			pstmt.setLong(13,bean.getUserId());
			pstmt.setLong(14, bean.getId());
			pstmt.executeUpdate();
			conn.commit(); // End transaction
			pstmt.close();
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Database Exception..", e);
			try {
				conn.rollback();
			} catch (Exception ex) {
				throw new ApplicationException("Exception : Delete rollback exception " + ex.getMessage());
			}
			throw new ApplicationException("Exception in updating Customer ");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("Model update End");
	}

	/**
	 * Search Customer
	 * 
	 * @param bean
	 *            : Search Parameters
	 * @throws DatabaseException
	 */

	public List search(CustomerBean bean) throws ApplicationException {
		return search(bean, 0, 0);
	}

	

	public List search(CustomerBean bean, int pageNo, int pageSize) throws ApplicationException {
		log.debug("Model search Started");
		StringBuffer sql = new StringBuffer("SELECT * FROM Customer WHERE 1=1");

		if (bean != null) {
			if (bean.getId() > 0) {
				sql.append(" AND id = " + bean.getId());
			}
			if (bean.getFirstName() != null && bean.getFirstName().length() > 0) {
				sql.append(" AND FirstName like '" + bean.getFirstName() + "%'");
			}
			
			
		

		}

		// if page size is greater than zero then apply pagination
		if (pageSize > 0) {
			// Calculate start record index
			pageNo = (pageNo - 1) * pageSize;

			sql.append(" Limit " + pageNo + ", " + pageSize);
			// sql.append(" limit " + pageNo + "," + pageSize);
		}

		System.out.println("Customer model search  :"+sql);
		ArrayList list = new ArrayList();
		Connection conn = null;
		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				bean = new CustomerBean();
				bean.setId(rs.getLong(1));
				bean.setFirstName(rs.getString(2));
				bean.setLastName(rs.getString(3));
				bean.setAddress(rs.getString(4));
				bean.setCity(rs.getString(5));
				bean.setState(rs.getString(6));
				bean.setZipCode(rs.getString(7));
				bean.setTelephone(rs.getString(8));
				bean.setEmail(rs.getString(9));
				bean.setAccountNum(rs.getString(10));
				bean.setAccountDate(rs.getString(11));
				bean.setCreaditCard(rs.getString(12));
				bean.setPreferences(rs.getString(13));
				bean.setUserId(rs.getLong(14));
				list.add(bean);
			}
			rs.close();
		} catch (Exception e) {
			log.error("Database Exception..", e);
			throw new ApplicationException("Exception : Exception in search Customer");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}

		log.debug("Model search End");
		return list;
	}

	/**
	 * Get List of Customer
	 * 
	 * @return list : List of Customer
	 * @throws DatabaseException
	 */

	public List list() throws ApplicationException {
		return list(0, 0);
	}

	/**
	 * Get List of Customer with pagination
	 * 
	 * @return list : List of Customers
	 * @param pageNo
	 *            : Current Page No.
	 * @param pageSize
	 *            : Size of Page
	 * @throws DatabaseException
	 */

	public List list(int pageNo, int pageSize) throws ApplicationException {
		log.debug("Model list Started");
		ArrayList list = new ArrayList();
		StringBuffer sql = new StringBuffer("select * from Customer");
		// if page size is greater than zero then apply pagination
		if (pageSize > 0) {
			// Calculate start record index
			pageNo = (pageNo - 1) * pageSize;
			sql.append(" limit " + pageNo + "," + pageSize);
		}

		
		System.out.println("sql in list Customer :"+sql);
		Connection conn = null;

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				CustomerBean bean = new CustomerBean();
				bean.setId(rs.getLong(1));
				bean.setFirstName(rs.getString(2));
				bean.setLastName(rs.getString(3));
				bean.setAddress(rs.getString(4));
				bean.setCity(rs.getString(5));
				bean.setState(rs.getString(6));
				bean.setZipCode(rs.getString(7));
				bean.setTelephone(rs.getString(8));
				bean.setEmail(rs.getString(9));
				bean.setAccountNum(rs.getString(10));
				bean.setAccountDate(rs.getString(11));
				bean.setCreaditCard(rs.getString(12));
				bean.setPreferences(rs.getString(13));
				bean.setUserId(rs.getLong(14));
				list.add(bean);
			}
			rs.close();
		} catch (Exception e) {
			log.error("Database Exception..", e);
			throw new ApplicationException("Exception : Exception in getting list of Customer");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}

		log.debug("Model list End");
		return list;

	}

}
