package in.co.air.line.ticket.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import beanObjs.BaseBean;
import beanObjs.RouteBean;
import in.co.air.line.ticket.exception.ApplicationException;
import in.co.air.line.ticket.exception.DuplicateRecordException;
import in.co.air.line.ticket.model.AirLineModel;
import in.co.air.line.ticket.model.AirportModel;
import in.co.air.line.ticket.model.FlightModel;
import in.co.air.line.ticket.model.RouteModel;
import in.co.air.line.ticket.util.DataUtility;
import in.co.air.line.ticket.util.DataValidator;
import in.co.air.line.ticket.util.PropertyReader;
import in.co.air.line.ticket.util.ServletUtility;

/**
 * Servlet implementation class RouteCtl
 */
@WebServlet(name="RouteCtl",urlPatterns={"/ctl/RouteCtl"})
public class RouteCtl extends BaseCtl {
	private static final long serialVersionUID = 1L;
       
	private static Logger log=Logger.getLogger(RouteCtl.class);
	/**
	 * Validate input Data Entered By User
	 * 
	 * @param request
	 * @return
	 */
	
	
	@Override
    protected boolean validate(HttpServletRequest request) {
		log.debug("RouteCtl validate method start");
        boolean pass = true;

       
        
        if (DataValidator.isNull(request.getParameter("date"))) {
            request.setAttribute("date",
                    PropertyReader.getValue("error.require", "Dept Date"));
            pass = false;
        }
        
        if ("-----Select-----".equals(request.getParameter("airLineId"))) {
            request.setAttribute("airLineId",
                    PropertyReader.getValue("error.require", "AirLine Name"));
            pass = false;
        }
        if ("-----Select-----".equals(request.getParameter("flightId"))) {
            request.setAttribute("flightId",
                    PropertyReader.getValue("error.require", "Flight Name"));
            pass = false;
        }
        if ("-----Select-----".equals(request.getParameter("deptId"))) {
            request.setAttribute("deptId",
                    PropertyReader.getValue("error.require", "Dept Airport Name"));
            pass = false;
        }
        if ("-----Select-----".equals(request.getParameter("arrivId"))) {
            request.setAttribute("arrivId",
                    PropertyReader.getValue("error.require", "Arrival Airport Name"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("deptTime"))) {
            request.setAttribute("deptTime",
                    PropertyReader.getValue("error.require", "Dept Time"));
            pass = false;
        }
        if (DataValidator.isNull(request.getParameter("arrTime"))) {
            request.setAttribute("arrTime",
                    PropertyReader.getValue("error.require", "Arrival Time"));
            pass = false;
        }
      
        if (DataValidator.isNull(request.getParameter("price"))) {
            request.setAttribute("price",
                    PropertyReader.getValue("error.require", "Ticket Price"));
            pass = false;
        }

        log.debug("RouteCtl validate method end");
        return pass;
    }
	
	@Override
	protected void preload(HttpServletRequest request) {
		AirLineModel model=new AirLineModel();
		FlightModel fModel=new FlightModel();
		AirportModel aModel=new AirportModel();
		try {
			List list1=model.list();
			List list2=fModel.list();
			List list3=aModel.list();
			request.setAttribute("airLineList", list1);
			request.setAttribute("flightList", list2);
			request.setAttribute("airportList", list3);
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	protected BaseBean populateBean(HttpServletRequest request) {
		log.debug("RouteCtl populateBean method start");
		RouteBean bean=new RouteBean();
		bean.setId(DataUtility.getLong(request.getParameter("id")));
		bean.setFlightId(DataUtility.getLong(request.getParameter("flightId")));
		bean.setAirLineId(DataUtility.getLong(request.getParameter("airLineId")));
		bean.setDeptAirportId(DataUtility.getLong(request.getParameter("deptId")));
		bean.setArriveAirPortId(DataUtility.getLong(request.getParameter("arrivId")));
		bean.setDeptTime(DataUtility.getString(request.getParameter("deptTime")));
		bean.setArriveTime(DataUtility.getString(request.getParameter("arrTime")));
		bean.setDeptDate(DataUtility.getDate(request.getParameter("date")));
		bean.setTicketPrice(DataUtility.getDouble(request.getParameter("price")));
		
		log.debug("RouteCtl populateBean method end");
		return bean;
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug("RouteCtl doGet method start"); 
		String op = DataUtility.getString(request.getParameter("operation"));
			
		   RouteModel model = new RouteModel();
			long id = DataUtility.getLong(request.getParameter("id"));
			ServletUtility.setOpration("Add", request);
			if (id > 0 || op != null) {
				System.out.println("in id > 0  condition");
				RouteBean bean;
				try {
					bean = model.findByPK(id);
					ServletUtility.setOpration("Edit", request);
					ServletUtility.setBean(bean, request);
				} catch (ApplicationException e) {
					ServletUtility.handleException(e, request, response);
					return;
				}
			}

			ServletUtility.forward(getView(), request, response);
			log.debug("RouteCtl doGet method end");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug("RouteCtl doPost method start");
		String op=DataUtility.getString(request.getParameter("operation"));
		RouteModel model=new RouteModel();
		long id=DataUtility.getLong(request.getParameter("id"));
		if(OP_SAVE.equalsIgnoreCase(op)){
			
			RouteBean bean=(RouteBean)populateBean(request);
				try {
					if(id>0){
						
					model.update(bean);
					ServletUtility.setOpration("Edit", request);
					ServletUtility.setSuccessMessage("Data is successfully Updated", request);
	                ServletUtility.setBean(bean, request);

					}else {
						long pk=model.add(bean);
						//bean.setId(id);
						ServletUtility.setSuccessMessage("Data is successfully Saved", request);
						ServletUtility.forward(getView(), request, response);
					}
	              
				} catch (ApplicationException e) {
					e.printStackTrace();
					ServletUtility.forward(ATBView.ERROR_VIEW, request, response);
					return;
				
			} catch (DuplicateRecordException e) {
				ServletUtility.setBean(bean, request);
				ServletUtility.setErrorMessage(e.getMessage(),
						request);
			}
			
		}else if (OP_DELETE.equalsIgnoreCase(op)) {
		RouteBean bean=	(RouteBean)populateBean(request);
		try {
			model.delete(bean);
			ServletUtility.redirect(ATBView.ROUTE_LIST_CTL, request, response);
		} catch (ApplicationException e) {
			ServletUtility.handleException(e, request, response);
			e.printStackTrace();
		}
		}else if (OP_CANCEL.equalsIgnoreCase(op)) {
			ServletUtility.redirect(ATBView.ROUTE_LIST_CTL, request, response);
			return;
	}else if (OP_RESET.equalsIgnoreCase(op)) {
		ServletUtility.redirect(ATBView.ROUTE_CTL, request, response);
		return;
}
				
		
		ServletUtility.forward(getView(), request, response);
		 log.debug("RouteCtl doPost method end");
	}

	@Override
	protected String getView() {
		// TODO Auto-generated method stub
		return ATBView.ROUTE_VIEW;
	}

}
