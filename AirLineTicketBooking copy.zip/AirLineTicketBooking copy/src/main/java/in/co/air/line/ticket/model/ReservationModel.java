package in.co.air.line.ticket.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import beanObjs.ReservationBean;
import in.co.air.line.ticket.exception.ApplicationException;
import in.co.air.line.ticket.exception.DatabaseException;
import in.co.air.line.ticket.exception.DuplicateRecordException;
import in.co.air.line.ticket.util.JDBCDataSource;

public class ReservationModel {

private static Logger log = Logger.getLogger(ReservationModel.class);
	

	public Integer nextPK() throws DatabaseException {
		log.debug("Model nextPK Started");
		Connection conn = null;
		int pk = 0;

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(ID) FROM Reservation");
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				pk = rs.getInt(1);
			}
			rs.close();

		} catch (Exception e) {
			log.error("Database Exception..", e);
			throw new DatabaseException("Exception : Exception in getting PK");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("Model nextPK End");
		return pk + 1;
	}
	
	public Integer nextReservationNo() throws DatabaseException {
		log.debug("Model nextPK Started");
		Connection conn = null;
		int pk = 0;

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement("SELECT MAX(Reservation_No) FROM Reservation");
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				pk = rs.getInt(1);
			}
			rs.close();

		} catch (Exception e) {
			log.error("Database Exception..", e);
			throw new DatabaseException("Exception : Exception in getting PK");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("Model nextPK End");
		return pk + 1;
	}
	

	/**
	 * Add a Reservation
	 * 
	 * @param bean
	 * @throws DatabaseException
	 * 
	 */
	public long add(ReservationBean bean) throws ApplicationException, DuplicateRecordException {
		
		Connection conn = null;
		int pk = 0;

		/*ReservationBean existbean = findByReservationNo(bean.getReservationNo());

		if (existbean != null) {
			throw new DuplicateRecordException("Reservation already exists");
		}*/

		try {
			conn = JDBCDataSource.getConnection();
			pk = nextPK();
			// Get auto-generated next primary key
			System.out.println(pk + " in ModelJDBC");
			conn.setAutoCommit(false); // Begin transaction
			PreparedStatement pstmt = conn.prepareStatement("INSERT INTO Reservation VALUES(?,?,?,?,?,?,?,?,?,?,?)");
			pstmt.setInt(1, pk);
			pstmt.setInt(2, nextReservationNo());
			pstmt.setDouble(3, bean.getBookingFee());
			pstmt.setDouble(4, bean.getTotalFare());
			pstmt.setString(5, bean.getReservationDate());
			pstmt.setLong(6,bean.getCustomerId());
			pstmt.setLong(7,bean.getFlightId());
			pstmt.setLong(8,bean.getAirLineId());
			pstmt.setLong(9,bean.getDeptAirportId());
			pstmt.setLong(10,bean.getArriveAirportId());
			pstmt.setString(11,bean.getMonth());
			pstmt.executeUpdate();
			conn.commit(); // End transaction
			pstmt.close();
		} catch (Exception e) {
		
			try {
				conn.rollback();
			} catch (Exception ex) {
				ex.printStackTrace();
				throw new ApplicationException("Exception : add rollback exception " + ex.getMessage());
			}
			throw new ApplicationException("Exception : Exception in add Reservation");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		
		return pk;
	}

	/**
	 * Delete a Reservation
	 * 
	 * @param bean
	 * @throws DatabaseException
	 */
	public void delete(ReservationBean bean) throws ApplicationException {
		
		Connection conn = null;
		try {
			conn = JDBCDataSource.getConnection();
			conn.setAutoCommit(false); // Begin transaction
			PreparedStatement pstmt = conn.prepareStatement("DELETE FROM Reservation WHERE ID=?");
			pstmt.setLong(1, bean.getId());
			pstmt.executeUpdate();
			conn.commit(); // End transaction
			pstmt.close();

		} catch (Exception e) {
		
			try {
				conn.rollback();
			} catch (Exception ex) {
				throw new ApplicationException("Exception : Delete rollback exception " + ex.getMessage());
			}
			throw new ApplicationException("Exception : Exception in delete Reservation");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		
	}

	/**
	 * Find Reservation by Login
	 * 
	 * @param login
	 *            : get parameter
	 * @return bean
	 * @throws DatabaseException
	 */

	public ReservationBean findByReservationNo(String ReservationNo) throws ApplicationException {
		log.debug("Model findByLogin Started");
		StringBuffer sql = new StringBuffer("SELECT * FROM Reservation WHERE Reservation_No=?");
		ReservationBean bean = null;
		Connection conn = null;
		System.out.println("sql" + sql);

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, ReservationNo);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				bean = new ReservationBean();
				bean.setId(rs.getLong(1));
				bean.setReservationNo(rs.getInt(2));
				bean.setBookingFee(rs.getDouble(3));
				bean.setTotalFare(rs.getDouble(4));
				bean.setReservationDate(rs.getString(5));
				bean.setCustomerId(rs.getLong(6));
				bean.setFlightId(rs.getLong(7));
				bean.setAirLineId(rs.getLong(8));
				bean.setDeptAirportId(rs.getLong(9));
				bean.setArriveAirportId(rs.getLong(10));
				bean.setMonth(rs.getString(11));
			}
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Database Exception..", e);
			throw new ApplicationException("Exception : Exception in getting Reservation by login");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("Model findByLogin End");
		return bean;
	}

	/**
	 * Find Reservation by PK
	 * 
	 * @param pk
	 *            : get parameter
	 * @return bean
	 * @throws DatabaseException
	 */

	public ReservationBean findByPK(long pk) throws ApplicationException {
		log.debug("Model findByPK Started");
		StringBuffer sql = new StringBuffer("SELECT * FROM Reservation WHERE ID=?");
		ReservationBean bean = null;
		Connection conn = null;

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			pstmt.setLong(1, pk);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				bean = new ReservationBean();
				bean.setId(rs.getLong(1));
				bean.setReservationNo(rs.getInt(2));
				bean.setBookingFee(rs.getDouble(3));
				bean.setTotalFare(rs.getDouble(4));
				bean.setReservationDate(rs.getString(5));
				bean.setCustomerId(rs.getLong(6));
				bean.setFlightId(rs.getLong(7));
				bean.setAirLineId(rs.getLong(8));
				bean.setDeptAirportId(rs.getLong(9));
				bean.setArriveAirportId(rs.getLong(10));
				bean.setMonth(rs.getString(11));
			}
			rs.close();
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Database Exception..", e);
			throw new ApplicationException("Exception : Exception in getting Reservation by pk");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("Model findByPK End");
		return bean;
	}

	/**
	 * Update a Reservation
	 * 
	 * @param bean
	 * @throws DatabaseException
	 */

	public void update(ReservationBean bean) throws ApplicationException, DuplicateRecordException {
		log.debug("Model update Started");
		Connection conn = null;

		/*ReservationBean beanExist = findByReservationNo(bean.getReservationNo());
		// Check if updated LoginId already exist
		if (beanExist != null && !(beanExist.getId() == bean.getId())) {
			throw new DuplicateRecordException("Reservation is already exist");
		}*/

		try {
			conn = JDBCDataSource.getConnection();
			conn.setAutoCommit(false); // Begin transaction
			PreparedStatement pstmt = conn.prepareStatement(
					"UPDATE Reservation SET Reservation_No=?,bookingFee=?,TotalFare=?,reservationDate=?,customer_id=?,flight_id=?,airLine_Id=?,Dept_airport_Id=?,Arrive_Airport_Id=?,month=?"
					+ " WHERE ID=?");
			pstmt.setInt(1, bean.getReservationNo());
			pstmt.setDouble(2, bean.getBookingFee());
			pstmt.setDouble(3, bean.getTotalFare());
			pstmt.setString(4, bean.getReservationDate());
			pstmt.setLong(5,bean.getCustomerId());
			pstmt.setLong(6,bean.getFlightId());
			pstmt.setLong(7,bean.getAirLineId());
			pstmt.setLong(8,bean.getDeptAirportId());
			pstmt.setLong(9,bean.getArriveAirportId());
			pstmt.setString(10,bean.getMonth());
			pstmt.setLong(11,bean.getId());
			
			pstmt.executeUpdate();
			conn.commit(); // End transaction
			pstmt.close();
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Database Exception..", e);
			try {
				conn.rollback();
			} catch (Exception ex) {
				throw new ApplicationException("Exception : Delete rollback exception " + ex.getMessage());
			}
			throw new ApplicationException("Exception in updating Reservation ");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}
		log.debug("Model update End");
	}

	/**
	 * Search Reservation
	 * 
	 * @param bean
	 *            : Search Parameters
	 * @throws DatabaseException
	 */

	public List search(ReservationBean bean) throws ApplicationException {
		return search(bean, 0, 0);
	}

	

	public List search(ReservationBean bean, int pageNo, int pageSize) throws ApplicationException {
		log.debug("Model search Started");
		StringBuffer sql = new StringBuffer("SELECT * FROM Reservation WHERE 1=1");

		if (bean != null) {
			if (bean.getId() > 0) {
				sql.append(" AND id = " + bean.getId());
			}
			if (bean.getCustomerId() > 0) {
				sql.append(" AND customer_id = " + bean.getCustomerId());
			}
			
			
			/*if (bean.getReservationNo() != null && bean.getReservationNo().length() > 0) {
				sql.append(" AND Reservation_No like '" + bean.getReservationNo() + "%'");
			}*/
			if (bean.getMonth() != null && bean.getMonth().length() > 0) {
			sql.append(" AND Month like '" + bean.getMonth() + "%'");
		}
			
		

		}

		// if page size is greater than zero then apply pagination
		if (pageSize > 0) {
			// Calculate start record index
			pageNo = (pageNo - 1) * pageSize;

			sql.append(" Limit " + pageNo + ", " + pageSize);
			// sql.append(" limit " + pageNo + "," + pageSize);
		}

		System.out.println("Reservation model search  :"+sql);
		ArrayList list = new ArrayList();
		Connection conn = null;
		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				bean = new ReservationBean();
				bean.setId(rs.getLong(1));
				bean.setReservationNo(rs.getInt(2));
				bean.setBookingFee(rs.getDouble(3));
				bean.setTotalFare(rs.getDouble(4));
				bean.setReservationDate(rs.getString(5));
				bean.setCustomerId(rs.getLong(6));
				bean.setFlightId(rs.getLong(7));
				bean.setAirLineId(rs.getLong(8));
				bean.setDeptAirportId(rs.getLong(9));
				bean.setArriveAirportId(rs.getLong(10));
				bean.setMonth(rs.getString(11));
				list.add(bean);
			}
			rs.close();
		} catch (Exception e) {
			log.error("Database Exception..", e);
			throw new ApplicationException("Exception : Exception in search Reservation");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}

		log.debug("Model search End");
		return list;
	}

	/**
	 * Get List of Reservation
	 * 
	 * @return list : List of Reservation
	 * @throws DatabaseException
	 */

	public List list() throws ApplicationException {
		return list(0, 0);
	}

	/**
	 * Get List of Reservation with pagination
	 * 
	 * @return list : List of Reservations
	 * @param pageNo
	 *            : Current Page No.
	 * @param pageSize
	 *            : Size of Page
	 * @throws DatabaseException
	 */

	public List list(int pageNo, int pageSize) throws ApplicationException {
		log.debug("Model list Started");
		ArrayList list = new ArrayList();
		StringBuffer sql = new StringBuffer("select * from Reservation");
		// if page size is greater than zero then apply pagination
		if (pageSize > 0) {
			// Calculate start record index
			pageNo = (pageNo - 1) * pageSize;
			sql.append(" limit " + pageNo + "," + pageSize);
		}

		
		System.out.println("sql in list Reservation :"+sql);
		Connection conn = null;

		try {
			conn = JDBCDataSource.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql.toString());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				ReservationBean bean = new ReservationBean();
				bean.setId(rs.getLong(1));
				bean.setId(rs.getLong(1));
				bean.setReservationNo(rs.getInt(2));
				bean.setBookingFee(rs.getDouble(3));
				bean.setTotalFare(rs.getDouble(4));
				bean.setReservationDate(rs.getString(5));
				bean.setCustomerId(rs.getLong(6));
				bean.setFlightId(rs.getLong(7));
				bean.setAirLineId(rs.getLong(8));
				bean.setDeptAirportId(rs.getLong(9));
				bean.setArriveAirportId(rs.getLong(10));
				bean.setMonth(rs.getString(11));
				list.add(bean);
			}
			rs.close();
		} catch (Exception e) {
			log.error("Database Exception..", e);
			throw new ApplicationException("Exception : Exception in getting list of Reservation");
		} finally {
			JDBCDataSource.closeConnection(conn);
		}

		log.debug("Model list End");
		return list;

	}
	
	public static double getCustomerRevenue(long id) {
		double revenue=0.0;
		ReservationBean rbean=new ReservationBean();
		rbean.setCustomerId(id);
	
		try {
			List<ReservationBean> rev=new ReservationModel().search(rbean);
			for (ReservationBean reservationBean : rev) {
				revenue=revenue+reservationBean.getTotalFare();
			}
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return revenue;
	}
	
}
