package in.co.air.line.ticket.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import beanObjs.AirportBean;
import beanObjs.BaseBean;
import beanObjs.FlightBean;
import in.co.air.line.ticket.exception.ApplicationException;
import in.co.air.line.ticket.exception.DuplicateRecordException;
import in.co.air.line.ticket.model.AirLineModel;
import in.co.air.line.ticket.model.AirportModel;
import in.co.air.line.ticket.model.FlightModel;
import in.co.air.line.ticket.util.DataUtility;
import in.co.air.line.ticket.util.DataValidator;
import in.co.air.line.ticket.util.PropertyReader;
import in.co.air.line.ticket.util.ServletUtility;

/**
 * Servlet implementation class FlightCtl
 */
@WebServlet(name="FlightCtl",urlPatterns={"/ctl/FlightCtl"})
public class FlightCtl extends BaseCtl {
	private static final long serialVersionUID = 1L;
       
	private static Logger log=Logger.getLogger(FlightCtl.class);
	/**
	 * Validate input Data Entered By User
	 * 
	 * @param request
	 * @return
	 */
	
	
	@Override
    protected boolean validate(HttpServletRequest request) {
		log.debug("FlightCtl validate method start");
        boolean pass = true;

       
        
        if (DataValidator.isNull(request.getParameter("flightNo"))) {
            request.setAttribute("flightNo",
                    PropertyReader.getValue("error.require", "Flight No"));
            pass = false;
        }
        
        if ("-----Select-----".equals(request.getParameter("airLineId"))) {
            request.setAttribute("airLineId",
                    PropertyReader.getValue("error.require", "AirLine Name"));
            pass = false;
        }
        
        if ("-----Select-----".equals(request.getParameter("airPortId"))) {
            request.setAttribute("airPortId",
                    PropertyReader.getValue("error.require", "AirPort Name"));
            pass = false;
        }
        
        if (DataValidator.isNull(request.getParameter("days"))) {
            request.setAttribute("days",
                    PropertyReader.getValue("error.require", "Working Day"));
            pass = false;
        }
        if (DataValidator.isNull(request.getParameter("seat"))) {
            request.setAttribute("seat",
                    PropertyReader.getValue("error.require", "Total Seat"));
            pass = false;
        }
      

        log.debug("FlightCtl validate method end");
        return pass;
    }
	
	@Override
	protected void preload(HttpServletRequest request) {
		AirLineModel model=new AirLineModel();
		AirportModel aModel=new AirportModel();
		try {
			List list=model.list();
			List list1=aModel.list();
			request.setAttribute("airLineList", list);
			request.setAttribute("airPortList", list1);
		} catch (ApplicationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	protected BaseBean populateBean(HttpServletRequest request) {
		log.debug("FlightCtl populateBean method start");
		FlightBean bean=new FlightBean();
		bean.setId(DataUtility.getLong(request.getParameter("id")));
		bean.setFlightNo(DataUtility.getString(request.getParameter("flightNo")));
		bean.setWorkingDays(DataUtility.getString(request.getParameter("days")));
		bean.setSeatTotal(DataUtility.getInt(request.getParameter("seat")));
		bean.setAirLineId(DataUtility.getLong(request.getParameter("airLineId")));
		bean.setAirPortId(DataUtility.getLong(request.getParameter("airPortId")));
		log.debug("FlightCtl populateBean method end");
		return bean;
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug("FlightCtl doGet method start"); 
		String op = DataUtility.getString(request.getParameter("operation"));
			
		   FlightModel model = new FlightModel();
			long id = DataUtility.getLong(request.getParameter("id"));
			ServletUtility.setOpration("Add", request);
			if (id > 0 || op != null) {
				System.out.println("in id > 0  condition");
				FlightBean bean;
				try {
					bean = model.findByPK(id);
					ServletUtility.setOpration("Edit", request);
					ServletUtility.setBean(bean, request);
				} catch (ApplicationException e) {
					ServletUtility.handleException(e, request, response);
					return;
				}
			}

			ServletUtility.forward(getView(), request, response);
			log.debug("FlightCtl doGet method end");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		log.debug("FlightCtl doPost method start");
		String op=DataUtility.getString(request.getParameter("operation"));
		FlightModel model=new FlightModel();
		long id=DataUtility.getLong(request.getParameter("id"));
		if(OP_SAVE.equalsIgnoreCase(op)){
			
			FlightBean bean=(FlightBean)populateBean(request);
				try {
					if(id>0){
						
					model.update(bean);
					ServletUtility.setOpration("Edit", request);
					ServletUtility.setSuccessMessage("Data is successfully Updated", request);
	                ServletUtility.setBean(bean, request);

					}else {
						long pk=model.add(bean);
						//bean.setId(id);
						ServletUtility.setSuccessMessage("Data is successfully Saved", request);
						ServletUtility.forward(getView(), request, response);
					}
	              
				} catch (ApplicationException e) {
					e.printStackTrace();
					ServletUtility.forward(ATBView.ERROR_VIEW, request, response);
					return;
				
			} catch (DuplicateRecordException e) {
				ServletUtility.setBean(bean, request);
				ServletUtility.setErrorMessage(e.getMessage(),
						request);
			}
			
		}else if (OP_DELETE.equalsIgnoreCase(op)) {
		FlightBean bean=	(FlightBean)populateBean(request);
		try {
			model.delete(bean);
			ServletUtility.redirect(ATBView.FLIGHT_LIST_CTL, request, response);
		} catch (ApplicationException e) {
			ServletUtility.handleException(e, request, response);
			e.printStackTrace();
		}
		}else if (OP_CANCEL.equalsIgnoreCase(op)) {
			ServletUtility.redirect(ATBView.FLIGHT_LIST_CTL, request, response);
			return;
	}else if (OP_RESET.equalsIgnoreCase(op)) {
		ServletUtility.redirect(ATBView.FLIGHT_CTL, request, response);
		return;
}
				
		
		ServletUtility.forward(getView(), request, response);
		 log.debug("FlightCtl doPost method end");
	}

	@Override
	protected String getView() {
		// TODO Auto-generated method stub
		return ATBView.FLIGHT_VIEW;
	}

}
