package beanObjs;

public class AirLineBean extends BaseBean {

	
	
	
	private String AirLine_Name;
	
	
	public AirLineBean() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "AirLineBean [id=" + id + ", AirLine_Name=" + AirLine_Name + "]";
	}

	

	public String getAirLine_Name() {
		return AirLine_Name;
	}

	public void setAirLine_Name(String airLine_Name) {
		AirLine_Name = airLine_Name;
	}

	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return id+"";
	}

	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return AirLine_Name;
	}

}
