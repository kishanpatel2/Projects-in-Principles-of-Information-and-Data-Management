package beanObjs;

import java.util.Date;

public class RouteBean extends BaseBean {

	
	private long flightId;
	private long airLineId;
	private long deptAirportId;
	private long arriveAirPortId;
	private String deptTime;
	private String arriveTime;
	private Date deptDate;
	private double ticketPrice;
	
	public RouteBean() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	@Override
	public String toString() {
		return "RouteBean [flightId=" + flightId + ", airLineId=" + airLineId + ", deptAirportId=" + deptAirportId
				+ ", arriveAirPortId=" + arriveAirPortId + ", deptTime=" + deptTime + ", arriveTime=" + arriveTime
				+ ", deptDate=" + deptDate + ", ticketPrice=" + ticketPrice + "]";
	}

	
	

	public double getTicketPrice() {
		return ticketPrice;
	}



	public void setTicketPrice(double ticketPrice) {
		this.ticketPrice = ticketPrice;
	}



	public long getFlightId() {
		return flightId;
	}



	public void setFlightId(long flightId) {
		this.flightId = flightId;
	}



	public long getAirLineId() {
		return airLineId;
	}



	public void setAirLineId(long airLineId) {
		this.airLineId = airLineId;
	}



	public long getDeptAirportId() {
		return deptAirportId;
	}



	public void setDeptAirportId(long deptAirportId) {
		this.deptAirportId = deptAirportId;
	}



	public long getArriveAirPortId() {
		return arriveAirPortId;
	}



	public void setArriveAirPortId(long arriveAirPortId) {
		this.arriveAirPortId = arriveAirPortId;
	}



	public String getDeptTime() {
		return deptTime;
	}



	public void setDeptTime(String deptTime) {
		this.deptTime = deptTime;
	}



	public String getArriveTime() {
		return arriveTime;
	}



	public void setArriveTime(String arriveTime) {
		this.arriveTime = arriveTime;
	}



	public Date getDeptDate() {
		return deptDate;
	}



	public void setDeptDate(Date deptDate) {
		this.deptDate = deptDate;
	}



	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
