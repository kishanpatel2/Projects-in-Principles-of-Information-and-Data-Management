package beanObjs;

public class ReservationBean extends BaseBean {

	private int reservationNo;
	private double bookingFee;
	private double totalFare;
	private String reservationDate;
	private long customerId;
	private long flightId;
	private long airLineId;
	private long deptAirportId;
	private long arriveAirportId;
	
	private String month;
	
	
	
	public String getMonth() {
		return month;
	}



	public void setMonth(String month) {
		this.month = month;
	}



	public ReservationBean() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	@Override
	public String toString() {
		return "ReservationBean [reservationNo=" + reservationNo + ", bookingFee=" + bookingFee + ", totalFare="
				+ totalFare + ", reservationDate=" + reservationDate + ", customerId=" + customerId + ", flightId="
				+ flightId + ", airLineId=" + airLineId + ", deptAirportId=" + deptAirportId + ", arriveAirportId="
				+ arriveAirportId + "]";
	}

	


	public int getReservationNo() {
		return reservationNo;
	}



	public void setReservationNo(int reservationNo) {
		this.reservationNo = reservationNo;
	}



	public double getBookingFee() {
		return bookingFee;
	}



	public void setBookingFee(double bookingFee) {
		this.bookingFee = bookingFee;
	}



	public double getTotalFare() {
		return totalFare;
	}



	public void setTotalFare(double totalFare) {
		this.totalFare = totalFare;
	}



	public String getReservationDate() {
		return reservationDate;
	}



	public void setReservationDate(String reservationDate) {
		this.reservationDate = reservationDate;
	}



	public long getCustomerId() {
		return customerId;
	}



	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}



	public long getFlightId() {
		return flightId;
	}



	public void setFlightId(long flightId) {
		this.flightId = flightId;
	}



	public long getAirLineId() {
		return airLineId;
	}



	public void setAirLineId(long airLineId) {
		this.airLineId = airLineId;
	}



	public long getDeptAirportId() {
		return deptAirportId;
	}



	public void setDeptAirportId(long deptAirportId) {
		this.deptAirportId = deptAirportId;
	}



	public long getArriveAirportId() {
		return arriveAirportId;
	}



	public void setArriveAirportId(long arriveAirportId) {
		this.arriveAirportId = arriveAirportId;
	}



	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return null;
	}

}
