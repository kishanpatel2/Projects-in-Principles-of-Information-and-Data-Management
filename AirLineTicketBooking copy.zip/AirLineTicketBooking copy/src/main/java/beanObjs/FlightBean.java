package beanObjs;

import java.util.Date;

public class FlightBean extends BaseBean {
	
	
	private String flightNo;
	private long airLineId;
	private String workingDays;
	private int seatTotal;
	private long airPortId;
	
	

	public FlightBean() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	@Override
	public String toString() {
		return "FlightBean [flightNo=" + flightNo + ", airLineId=" + airLineId + ", workingDays=" + workingDays
				+ ", seatTotal=" + seatTotal + "]";
	}


	

	public long getAirPortId() {
		return airPortId;
	}



	public void setAirPortId(long airPortId) {
		this.airPortId = airPortId;
	}



	public String getFlightNo() {
		return flightNo;
	}



	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}



	public long getAirLineId() {
		return airLineId;
	}



	public void setAirLineId(long airLineId) {
		this.airLineId = airLineId;
	}



	public String getWorkingDays() {
		return workingDays;
	}



	public void setWorkingDays(String workingDays) {
		this.workingDays = workingDays;
	}



	public int getSeatTotal() {
		return seatTotal;
	}



	public void setSeatTotal(int seatTotal) {
		this.seatTotal = seatTotal;
	}



	public String getKey() {
		// TODO Auto-generated method stub
		return id+"";
	}

	public String getValue() {
		// TODO Auto-generated method stub
		return flightNo;
	}

}
