package beanObjs;

public class CustomerBean extends BaseBean {

	private String firstName;
	private String lastName;
	private String address;
	private String city;
	private String state;
	private String zipCode;
	private String telephone;
	private String email;
	private String accountNum;
	private String creaditCard;
	private String accountDate;
	private String preferences;
	private long userId;
	
	
	public CustomerBean() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	@Override
	public String toString() {
		return "CustomerBean [firstName=" + firstName + ", lastName=" + lastName + ", address=" + address + ", city="
				+ city + ", state=" + state + ", zipCode=" + zipCode + ", telephone=" + telephone + ", email=" + email
				+ ", accountNum=" + accountNum + ", creaditCard=" + creaditCard + ", accountDate=" + accountDate
				+ ", preferences=" + preferences + ", userId=" + userId + "]";
	}

	

	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) {
		this.lastName = lastName;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public String getCity() {
		return city;
	}



	public void setCity(String city) {
		this.city = city;
	}



	public String getState() {
		return state;
	}



	public void setState(String state) {
		this.state = state;
	}



	public String getZipCode() {
		return zipCode;
	}



	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}



	public String getTelephone() {
		return telephone;
	}



	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getAccountNum() {
		return accountNum;
	}



	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}



	public String getCreaditCard() {
		return creaditCard;
	}



	public void setCreaditCard(String creaditCard) {
		this.creaditCard = creaditCard;
	}



	public String getAccountDate() {
		return accountDate;
	}



	public void setAccountDate(String accountDate) {
		this.accountDate = accountDate;
	}



	public String getPreferences() {
		return preferences;
	}



	public void setPreferences(String preferences) {
		this.preferences = preferences;
	}



	public long getUserId() {
		return userId;
	}



	public void setUserId(long userId) {
		this.userId = userId;
	}



	@Override
	public String getKey() {
		// TODO Auto-generated method stub
		return id+"";
	}

	@Override
	public String getValue() {
		// TODO Auto-generated method stub
		return firstName+" "+lastName;
	}

}
